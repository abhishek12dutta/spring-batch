package com.ba.psd.poc.batch.reader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;

import com.ba.psd.poc.batch.model.FxMarketEvent;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

/**
 * The Class FxMarketEventReader.
 *
 * @author abhishek
 */

public class FxMarketEventReader extends FlatFileItemReader<FxMarketEvent> {
	private static final Logger log = LoggerFactory.getLogger(FxMarketEventReader.class);

	public FxMarketEventReader(String inputFileDir,String transactionType) {
		log.debug("Transaction Type is---" + transactionType);
		log.debug("Thread Number:-->[ " + Thread.currentThread().getId() +" : "+ Thread.currentThread().getName() + "]  stared reading ....");
		//Set input file

		//Resource

		Resource resource = new FileSystemResource(inputFileDir+"\\trades.csv");
		//this.setResource(new ClassPathResource("trades.csv.bkp"));
		this.setResource(resource);
		//Skip the file header line
		this.setLinesToSkip(1);
		//Line is mapped to item (FxMarketEvent) using setLineMapper(LineMapper)
		this.setLineMapper(new DefaultLineMapper<FxMarketEvent>() {
			{
				setLineTokenizer(new DelimitedLineTokenizer() {
					{
						setNames(new String[] { "stock", "time", "price", "shares" });
					}
				});
				setFieldSetMapper(new BeanWrapperFieldSetMapper<FxMarketEvent>() {
					{
						setTargetType(FxMarketEvent.class);
					}
				});
			}
		});
	}

}
