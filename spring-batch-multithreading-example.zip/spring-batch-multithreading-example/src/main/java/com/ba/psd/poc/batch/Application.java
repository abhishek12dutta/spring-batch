package com.ba.psd.poc.batch;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The Class Application.
 * 
 * @author abhishek
 */
@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	JobLauncher jobLauncher;

	@Autowired
	@Qualifier("fxMarketPricesETLJob")
	Job job;

	public static void main(String[] args) throws Exception {
		SpringApplication.run(Application.class, args);
		System.exit(0);
	}


	public void run(String... args) throws Exception
	{
		JobParameters params = new JobParametersBuilder()
				.addString("JobID", String.valueOf(System.currentTimeMillis()))
				.addString("transactionType","GBP")
				.toJobParameters();
		jobLauncher.run(job, params);
	}
}
