package com.ba.psd.poc.batch;

import com.ba.psd.poc.batch.exception.FileVerificationSkipper;
import com.ba.psd.poc.batch.listener.ChunkExecutionListener;
import com.ba.psd.poc.batch.listener.JobCompletionNotificationListener;
import com.ba.psd.poc.batch.model.FxMarketEvent;
import com.ba.psd.poc.batch.model.FxMarketVolumeStore;
import com.ba.psd.poc.batch.model.Trade;
import com.ba.psd.poc.batch.processor.FxMarketEventProcessor;
import com.ba.psd.poc.batch.reader.FxMarketEventReader;
import com.ba.psd.poc.batch.writer.StockVolumeAggregator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.skip.SkipPolicy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * The Class BatchConfiguration.
 * 
 * @author ashraf
 */
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	private static final Logger log = LoggerFactory.getLogger(BatchConfiguration.class);

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;


	@Value("${chunk-size}")
	private int chunkSize;

	@Value("${max-pool-size}")
	private int maxPoolSize;

	@Value("${core-pool-size}")
	private int corePoolSize;

	@Value("${thread-throttle-limit}")
	private int threadThrottleLimit;

	@Value("${input-file-directory}")
	private String inputFileDir;


	@Bean
	public FxMarketVolumeStore fxMarketPricesStore() {
		return new FxMarketVolumeStore();
	}

	// FxMarketEventReader (Reader)
	@Bean
	@StepScope
	public FxMarketEventReader fxMarketEventReader(@Value("#{jobParameters[transactionType]}") String transactionType) {
		return new FxMarketEventReader(inputFileDir,transactionType);
	}

	// FxMarketEventProcessor (Processor)
	@Bean
	public FxMarketEventProcessor fxMarketEventProcessor() {
		return new FxMarketEventProcessor();
	}

	// StockVolumeAggregator (Writer)
	@Bean
	public StockVolumeAggregator stockVolumeAggregator() {
		return new StockVolumeAggregator();
	}

	// JobCompletionNotificationListener (File loader)
	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionNotificationListener();
	}

	@Bean
	public SkipPolicy fileVerificationSkipper() {
		return new FileVerificationSkipper();
	}

	@Bean
	public ChunkExecutionListener chunkListener() {
		return new ChunkExecutionListener();
	}

	// Configure job step
	@Bean(name = "fxMarketPricesETLJob")
	public Job fxMarketPricesETLJob() {
		log.debug("Batch Started........................");
		return jobBuilderFactory.get("FxMarket Volume ETL Job").incrementer(new RunIdIncrementer()).
				listener(listener())
				.flow(etlStep()).end().build();
	}
	
//	@Bean
//	public TaskExecutor taskExecutor(){
//	    SimpleAsyncTaskExecutor asyncTaskExecutor=new SimpleAsyncTaskExecutor("spring_batch");
//	    asyncTaskExecutor.setConcurrencyLimit(5);
//	    return asyncTaskExecutor;
//	}


	@Bean
	public ThreadPoolTaskExecutor taskExecutor() {
		ThreadPoolTaskExecutor pool = new ThreadPoolTaskExecutor();
		pool.setCorePoolSize(corePoolSize);
		pool.setMaxPoolSize(maxPoolSize);
		//pool.setWaitForTasksToCompleteOnShutdown(true);
		return pool;
	}


	@Bean
	public Step etlStep() {
		return stepBuilderFactory.get("Extract -> Transform -> Aggregate -> Load").<FxMarketEvent, Trade> chunk(chunkSize)
				.reader(fxMarketEventReader(null))
				.faultTolerant().skipPolicy(fileVerificationSkipper())
				.processor(fxMarketEventProcessor())
				.writer(stockVolumeAggregator())
				.taskExecutor(taskExecutor()).listener(chunkListener())
				.throttleLimit(threadThrottleLimit)
				.build();
	}

}
